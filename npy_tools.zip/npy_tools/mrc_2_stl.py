"""
mrc_to_stl.py

Converts a binary segmentation mask (.mrc or .tif) into an STL mesh file
for import into Blender or other 3D software.

Uses marching cubes to generate a surface mesh from the binary volume,
then exports it as an STL via trimesh.

Inputs:
    binary_file : path to binary segmentation mask (.mrc or .tif)
    stl_name    : output filename e.g. "vesicles.stl"
    smooth      : if True, applies Laplacian smoothing to the mesh before export
    smooth_iter : number of smoothing iterations (default 10, ignored if smooth=False)

Outputs:
    {stl_name} : STL mesh file saved to working directory

Usage:
    Call mrc_to_stl() with your mask file and desired output name.
"""

import numpy as np


def mrc_to_stl(
    binary_file: str,
    stl_name: str,
    smooth: bool = False,
    smooth_iter: int = 10,
):
    """
    Convert a binary segmentation mask to an STL mesh using marching cubes.

    Parameters
    ----------
    binary_file : path to binary segmentation mask (.mrc or .tif)
    stl_name    : output STL filename e.g. "vesicles.stl"
    smooth      : if True, applies Laplacian smoothing before export
    smooth_iter : number of Laplacian smoothing iterations
    """

    from skimage import measure
    import trimesh

    # ------------------------------------------------------------------ load
    mask = _load_stack(binary_file)
    mask = (mask > 0).astype(np.uint8)

    print(f"Loaded mask | shape: {mask.shape} | "
          f"nonzero voxels: {np.count_nonzero(mask):,}")

    # --------------------------------------------------------- marching cubes
    verts, faces, normals, _ = measure.marching_cubes(mask, level=0.5)
    print(f"Marching cubes complete | verts: {len(verts):,} | faces: {len(faces):,}")

    # ------------------------------------------------------------------ mesh
    mesh = trimesh.Trimesh(vertices=verts, faces=faces, vertex_normals=normals)

    # ------------------------------------------------------- optional smooth
    if smooth:
        trimesh.smoothing.filter_laplacian(mesh, iterations=smooth_iter)
        print(f"Laplacian smoothing applied ({smooth_iter} iterations)")

    # ---------------------------------------------------------------- export
    if not stl_name.endswith(".stl"):
        stl_name += ".stl"

    mesh.export(stl_name)
    print(f"Saved: {stl_name}")


# ------------------------------------------------------------------ helpers

def _load_stack(path: str) -> np.ndarray:
    """Loads a .mrc or .tif image stack into a numpy array."""
    if path.endswith(".mrc"):
        import mrcfile
        with mrcfile.open(path, permissive=True) as f:
            return f.data.copy()
    elif path.endswith((".tif", ".tiff")):
        import tifffile
        return tifffile.imread(path)
    else:
        raise ValueError(f"Unsupported file format: '{path}'. Use .mrc or .tif/.tiff.")


# ------------------------------------------------------------------ example
if __name__ == "__main__":

    # --- basic conversion
    mrc_to_stl(
        binary_file = "vesicle_mask.mrc",
        stl_name    = "vesicles.stl",
        smooth      = False,
    )

    # --- with smoothing
    # mrc_to_stl(
    #     binary_file = "mito_mask.tif",
    #     stl_name    = "mitochondria.stl",
    #     smooth      = True,
    #     smooth_iter = 15,
    # )

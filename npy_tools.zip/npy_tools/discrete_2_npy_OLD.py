"""
voxelgen_npy_discreteparam.py

Generates NPY files for voxel visualization by mapping a discrete/categorical
parameter (e.g. cluster assignment, contact binary) from centroid positions
onto whole organelle structures using connected components labelling.

This version keeps the new checkpointed structure, but the assignment logic
matches the older behavior:
- centroid coordinates are used to find the nearest cc3d label
- the category is then flooded across the entire connected component
- category normalization is category / num_categories
- binary mode maps directly to 0.0 / 1.0

Outputs (saved to working directory):
    Binary_Mask_{organelle_name}_{cell_num}.npy
    Discrete_{param_name}_Mask_{organelle_name}_{cell_num}.npy
"""

import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cc3d
from tqdm import tqdm


def voxelgen_npy_discreteparam(
    binary_file: str,
    json_file: str,
    organelle_name: str,
    param_name: str,
    condition: str,
    cell_num: int,
    num_categories: int = None,
    binary: bool = False,
    window: int = 3,
    show_slice: bool = False,
    slice_index: int = None,
):
    """
    Map a discrete/categorical parameter from centroid JSON onto organelle structures.

    Assignment direction: each centroid locates its own label in the cc3d array
    via a voxel window search, then floods that label with the category value.
    """

    # ------------------------------------------------------------------ load
    print(f"[1/4] Loading files...")
    mask = _load_stack(binary_file)
    centroids = _load_centroids(json_file, condition, cell_num, param_name)

    if not centroids:
        raise ValueError(
            f"No centroids found for condition='{condition}', cell={cell_num}. "
            f"Check your JSON and filter values."
        )

    centroids_df = pd.DataFrame(centroids)

    print(
        f"      '{organelle_name}' | shape: {mask.shape} | "
        f"centroids loaded: {len(centroids_df)}"
    )

    # ---- validate param values are discrete (integer-like)
    raw_vals = [c[param_name] for c in centroids if c.get(param_name) is not None]
    if not all(float(v).is_integer() for v in raw_vals):
        raise ValueError(
            f"Parameter '{param_name}' contains non-integer values. "
            f"Use voxelgen_npy_rangeparam for continuous parameters."
        )

    unique_cats = sorted(set(int(v) for v in raw_vals))
    print(f"      Categories found: {unique_cats}")

    if not binary and num_categories is None:
        raise ValueError(
            "num_categories is required when binary=False. "
            "Pass the total number of categories e.g. num_categories=6."
        )

    if binary:
        invalid = [v for v in unique_cats if v not in (0, 1)]
        if invalid:
            raise ValueError(
                f"binary=True but found non-binary values: {invalid}. "
                f"Use binary=False with num_categories for multi-category params."
            )

    # -------------------------------------------------- save binary mask
    print(f"[2/4] Saving binary mask...")
    np.save(f"Binary_Mask_{organelle_name}_{cell_num}.npy", (mask > 0).astype(np.uint8))

    # ----------------------------------------- connected components labelling
    print(f"[3/4] Running connected components labelling...")
    labels = cc3d.connected_components(mask, connectivity=18)
    print(f"      Structures found: {int(labels.max())}")

    # ----------------------------------------- centroid -> label matching
    print(f"[4/4] Matching centroids to labels and assigning categories...")

    # New-format flow with tqdm:
    # 1) find label for each centroid
    # 2) keep centroids that matched a structure
    # 3) build label -> category mapping
    # 4) flood that category across the whole label

    param_array = np.zeros_like(mask, dtype=np.float32)
    matched = 0
    unmatched = 0
    label_list = []

    for x, y, z in tqdm(
        centroids_df[["x", "y", "z"]].values,
        desc="  Centroids",
        unit="centroid",
    ):
        label_id = _get_label_at(x, y, z, labels, window)
        label_list.append(label_id)

        if label_id == 0:
            unmatched += 1
        else:
            matched += 1

    centroids_df["Label"] = label_list
    valid_centroids = centroids_df[centroids_df["Label"] > 0]

    print(f"      Matched centroids: {matched} / {len(centroids_df)}")
    if unmatched > 0:
        print(f"      Tip: increase 'window' (currently {window}) if unmatched count is high.")

    param = dict(zip(valid_centroids["Label"], valid_centroids[param_name]))

    for labelval, paramval in param.items():
        category = int(paramval)

        if binary:
            mapped_val = float(category)
        else:
            mapped_val = round(category / num_categories, 2)

        param_array[labels == labelval] = mapped_val
        print(labelval, paramval)

    print("      Values assigned!")

    # --------------------------------------------------------- optional QC slice
    if show_slice:
        z = slice_index if slice_index is not None else mask.shape[0] // 2
        plt.figure(figsize=(7, 5))
        plt.imshow(param_array[z], cmap="nipy_spectral", vmin=0, vmax=1)
        plt.colorbar(label=f"{param_name} (normalized)")
        plt.title(f"{organelle_name} — {param_name} | z-slice {z}")
        plt.tight_layout()
        plt.show()

    # ----------------------------------------------------------- save output
    out_name = f"{param_name.replace('.', '_')}_Mask_{organelle_name}_{cell_num}.npy"
    np.save(out_name, param_array)

    print(f"Done! Saved:")
    print(f"  Binary_Mask_{organelle_name}_{cell_num}.npy")
    print(f"  {out_name}")


# ------------------------------------------------------------------ helpers

def _get_label_at(z: int, y: int, x: int, labels: np.ndarray, window: int) -> int:
    """
    Returns the most common non-zero label in a cubic window centred at (z, y, x).
    Returns 0 if no labelled voxel is found within the window.
    """
    z, y, x = int(z), int(y), int(x)
    zmin = max(0, z - window);  zmax = min(labels.shape[0], z + window + 1)
    ymin = max(0, y - window);  ymax = min(labels.shape[1], y + window + 1)
    xmin = max(0, x - window);  xmax = min(labels.shape[2], x + window + 1)

    region = labels[zmin:zmax, ymin:ymax, xmin:xmax]
    nonzero = region[region > 0]

    if nonzero.size == 0:
        return 0

    return int(np.bincount(nonzero).argmax())


def _load_stack(path: str) -> np.ndarray:
    """Loads a .mrc or .tif/.tiff image stack into a numpy array."""
    if path.endswith(".mrc"):
        import mrcfile
        with mrcfile.open(path, permissive=True) as f:
            return f.data.copy()
    elif path.endswith((".tif", ".tiff")):
        import tifffile
        return tifffile.imread(path)
    else:
        raise ValueError(f"Unsupported file format: '{path}'. Use .mrc or .tif/.tiff.")


def _load_centroids(
    json_file: str,
    condition: str,
    cell_num: int,
    param_name: str,
) -> list:
    with open(json_file) as f:
        data = json.load(f)

    cell_key = f"Cell {cell_num}"

    if condition not in data["conditions"]:
        available = list(data["conditions"].keys())
        raise ValueError(f"Condition '{condition}' not found. Available: {available}")

    cond_data = data["conditions"][condition]

    if cell_key not in cond_data:
        available = list(cond_data.keys())
        raise ValueError(
            f"'{cell_key}' not found in condition '{condition}'. Available: {available}"
        )

    cell_data = cond_data[cell_key]

    sample = _get_sample_centroid(cell_data)
    if sample and param_name not in sample and param_name != "Cluster":
        available = [k for k in sample.keys() if k not in ("x", "y", "z")]
        raise ValueError(f"Parameter '{param_name}' not found. Available: {available}")

    clustered = data["metadata"].get("clustered", True)

    if not clustered:
        centroids = cell_data["centroids"]
    else:
        centroids = []
        for cluster_id, cluster_centroids in cell_data.get("clusters", {}).items():
            for c in cluster_centroids:
                c2 = dict(c)
                c2["Cluster"] = int(cluster_id)
                centroids.append(c2)

    centroids = [c for c in centroids if c.get(param_name) is not None]
    return centroids


def _get_sample_centroid(cell_data: dict) -> dict:
    """Returns the first centroid in a cell data block regardless of structure."""
    if "centroids" in cell_data:
        return cell_data["centroids"][0] if cell_data["centroids"] else {}
    if "clusters" in cell_data:
        for cluster_centroids in cell_data["clusters"].values():
            if cluster_centroids:
                return cluster_centroids[0]
    return {}


# ------------------------------------------------------------------ example
if __name__ == "__main__":

    # --- map cluster assignments across whole cell
    voxelgen_npy_discreteparam(
        binary_file    = "vesicle_mask.mrc",
        json_file      = "centroids.json",
        organelle_name = "vesicles",
        param_name     = "Cluster",
        condition      = "No Stim",
        cell_num       = 1,
        num_categories = 6,
        window         = 3,
        show_slice     = True,
        slice_index    = None,
    )

    # --- binary contact parameter
    # voxelgen_npy_discreteparam(
    #     binary_file    = "vesicle_mask.mrc",
    #     json_file      = "centroids.json",
    #     organelle_name = "vesicles_contact",
    #     param_name     = "Mito.Contact",
    #     condition      = "Ex4",
    #     cell_num       = 7,
    #     binary         = True,
    #     window         = 3,
    #     show_slice     = True,
    # )
"""
csv_to_json.py

Converts a centroid CSV file into the hierarchical JSON format required
by the voxelgen NPY functions.

Output hierarchy:
    condition -> cell -> cluster -> centroids[]   (if clustered=True)
    condition -> cell -> centroids[]              (if clustered=False)

Expected CSV columns (minimum required):
    Centroid.X, Centroid.Y, Centroid.Z, Cell, Condition
    + Cluster (if clustered=True)
    + any number of parameter columns

All other columns are stored as parameters on each centroid.

Usage (command line):
    python csv_to_json.py --input data.csv --output data.json --organelle vesicles --source SXT

Usage (as a function):
    from csv_to_json import csv_to_json
    csv_to_json("data.csv", "data.json", organelle="vesicles", source="SXT")
"""

import argparse
import json
import numpy as np
import pandas as pd


# ------------------------------------------------------------------
# Column name constants — edit here if your CSV uses different names
# ------------------------------------------------------------------
COL_X         = "X"
COL_Y         = "Y"
COL_Z         = "Z"
COL_CELL      = "Cell"
COL_CONDITION = "Condition"
COL_CLUSTER   = "Cluster"
COL_GROUP     = "Group"

# Columns never stored as parameters
META_COLS = {COL_X, COL_Y, COL_Z, COL_CELL, COL_CONDITION, COL_CLUSTER, COL_GROUP}


def csv_to_json(
    input_path: str,
    output_path: str,
    organelle: str,
    source: str,
    clustered: bool = True,
) -> dict:
    """
    Convert a centroid CSV to a hierarchical JSON file.

    Parameters
    ----------
    input_path  : path to input CSV
    output_path : path to write JSON
    organelle   : organelle label e.g. "vesicles", "mitochondria"
    source      : imaging modality e.g. "SXT", "FIB-SEM", "cryo-ET"
    clustered   : if False, omits cluster level from hierarchy
    """

    df = pd.read_csv(input_path)

    # ---- validate required columns --------------------------------
    required = [COL_X, COL_Y, COL_Z, COL_CELL, COL_CONDITION]
    if clustered:
        required.append(COL_CLUSTER)
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"CSV is missing required columns: {missing}")

    # ---- normalize Cell to integer --------------------------------
    # handles both "Cell 1" strings and raw integers
    def parse_cell(val):
        if isinstance(val, str) and val.lower().startswith("cell"):
            return int(val.strip().split()[-1])
        return int(val)

    df["_cell_int"] = df[COL_CELL].apply(parse_cell)

    # ---- identify parameter columns --------------------------------
    param_cols = [c for c in df.columns if c not in META_COLS and c != "_cell_int"]

    # ---- build output ----------------------------------------------
    output = {
        "metadata": {
            "organelle":       organelle,
            "source":          source,
            "clustered":       clustered,
            "param_columns":   param_cols,
            "total_centroids": len(df),
        },
        "conditions": {}
    }

    for condition, cond_df in df.groupby(COL_CONDITION):
        output["conditions"][condition] = {}

        for cell_int, cell_df in cond_df.groupby("_cell_int"):
            cell_key = f"Cell {cell_int}"

            if clustered:
                clusters = {}
                for cluster_id, cluster_df in cell_df.groupby(COL_CLUSTER):
                    clusters[int(cluster_id)] = _rows_to_centroids(cluster_df, param_cols)
                output["conditions"][condition][cell_key] = {"clusters": clusters}
            else:
                output["conditions"][condition][cell_key] = {
                    "centroids": _rows_to_centroids(cell_df, param_cols)
                }

    # ---- write to disk ---------------------------------------------
    with open(output_path, "w") as f:
        json.dump(output, f, indent=2)

    # ---- summary ---------------------------------------------------
    total_cells = sum(len(v) for v in output["conditions"].values())
    print(f"Saved: {output_path}")
    print(f"  Organelle  : {organelle}")
    print(f"  Source     : {source}")
    print(f"  Conditions : {list(output['conditions'].keys())}")
    print(f"  Cells      : {total_cells}")
    print(f"  Centroids  : {len(df):,}")
    print(f"  Parameters : {param_cols}")

    return output


# ------------------------------------------------------------------ helpers

def _rows_to_centroids(df: pd.DataFrame, param_cols: list) -> list:
    """Converts a DataFrame slice into a list of centroid dicts."""
    records = []
    for _, row in df.iterrows():
        entry = {
            "x": round(float(row[COL_X]), 4),
            "y": round(float(row[COL_Y]), 4),
            "z": round(float(row[COL_Z]), 4),
        }
        for col in param_cols:
            val = row[col]
            if isinstance(val, float) and np.isnan(val):
                entry[col] = None
            elif isinstance(val, (np.integer,)):
                entry[col] = int(val)
            elif isinstance(val, (np.floating, float)):
                entry[col] = round(float(val), 6)
            else:
                entry[col] = val
        records.append(entry)
    return records


# ------------------------------------------------------------------ CLI

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Convert centroid CSV to hierarchical JSON for voxelgen NPY tools."
    )
    parser.add_argument("--input",      required=True,       help="Path to input CSV")
    parser.add_argument("--output",     required=True,       help="Path to output JSON")
    parser.add_argument("--organelle",  default="vesicles",  help="Organelle label")
    parser.add_argument("--source",     default="SXT",       help="Imaging modality")
    parser.add_argument("--no-cluster", action="store_true", help="Use if CSV has no Cluster column")
    args = parser.parse_args()

    csv_to_json(
        input_path  = args.input,
        output_path = args.output,
        organelle   = args.organelle,
        source      = args.source,
        clustered   = not args.no_cluster,
    )

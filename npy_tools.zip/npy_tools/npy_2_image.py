from matplotlib import pyplot as plt
import numpy as np
import tifffile as tiff

data = np.load("Binary_Mask_ISG_1_50_2.npy")
param = np.load("Image_Mask_ISG_1_50_2.npy")

x = np.shape(data)[0]
y = np.shape(data)[1]
z = np.round(np.shape(data)[2]/2).astype(int)

plt.imshow(data[:, :, z], cmap='gray')
plt.show()

plt.imshow(param[:, :, z], cmap='plasma')
plt.show()

tiff.imwrite("image_mask.tif", (param * 255).astype(np.uint8))
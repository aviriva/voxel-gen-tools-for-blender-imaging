"""
voxelgen_npy_param.py

Generates NPY files for voxel visualization by mapping either a continuous
parameter or a discrete/categorical parameter from centroid data onto whole
organelle structures using connected components labelling.

The shared workflow is:
    1) load binary mask
    2) load centroid data
    3) run connected components on the mask
    4) match centroids to nearby labels with a voxel window search
    5) assign values across whole connected components

Variable modes:
    continuous
        - values are clipped to [min_val, max_val]
        - then normalized to [0, 1]

    discrete
        - values are treated as integer categories
        - categories are mapped to category / num_categories
        - if binary=True, maps 0 -> 0.0 and 1 -> 1.0 directly

Inputs:
    binary_file    : path to binary segmentation mask (.mrc or .tif)
    json_file      : path to centroid JSON (produced by csv_to_json.py)
    csv_file       : optional CSV input if you want to skip JSON
    organelle_name : label for output filenames e.g. "vesicles"
    param_name     : parameter column to map e.g. "LAC.Value" or "Cluster"
    condition      : condition to filter by e.g. "No Stim" or "Ex4"
    cell_num       : integer cell number e.g. 1 for "Cell 1"
    cluster_num    : optional cluster filter for clustered JSON/CSV
    variable_type  : "continuous" or "discrete"
    num_categories : total number of categories for discrete mode
    binary         : if True, discrete mode maps 0/1 directly
    min_val        : continuous clip minimum
    max_val        : continuous clip maximum
    window         : voxel search radius around each centroid (default 3)
    show_hist      : if True, shows histogram for continuous mode
    show_slice     : if True, shows a 2D slice for discrete mode
    slice_index    : which z-slice to show — None = middle slice

Outputs:
    Binary_Mask_{organelle_name}_{cell_num}.npy
    Norm_{param_name}_Mask_{organelle_name}_{cell_num}.npy
    Discrete_{param_name}_Mask_{organelle_name}_{cell_num}.npy

Usage:
    Call voxelgen_npy_param() with your file paths and filter options.
"""

import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cc3d
from tqdm import tqdm


def voxelgen_npy_param(
    binary_file: str,
    organelle_name: str,
    param_name: str,
    condition: str,
    cell_num: int,
    json_file: str = None,
    csv_file: str = None,
    cluster_num: int = None,
    variable_type: str = "continuous",
    num_categories: int = None,
    binary: bool = False,
    min_val: float = None,
    max_val: float = None,
    window: int = 3,
    show_hist: bool = False,
    show_slice: bool = False,
    slice_index: int = None,
):
    """
    Map either a continuous or discrete parameter from centroid data onto
    whole organelle structures.

    Assignment direction:
        each centroid locates its own label in the cc3d array via a voxel
        window search, then floods that label with the mapped value.
    """
    variable_type = variable_type.lower().strip()
    if variable_type not in {"continuous", "discrete"}:
        raise ValueError("variable_type must be either 'continuous' or 'discrete'.")

    # ------------------------------------------------------------------ load
    print("[1/5] Loading files...")
    mask = _load_stack(binary_file)

    if csv_file is not None:
        centroids = _load_centroids_csv(
            csv_file=csv_file,
            condition=condition,
            cell_num=cell_num,
            cluster_num=cluster_num,
            param_name=param_name,
        )
    elif json_file is not None:
        centroids = _load_centroids_json(
            json_file=json_file,
            condition=condition,
            cell_num=cell_num,
            cluster_num=cluster_num,
            param_name=param_name,
        )
    else:
        raise ValueError("Provide either csv_file or json_file.")

    if not centroids:
        raise ValueError(
            f"No centroids found for condition='{condition}', "
            f"cell={cell_num}, cluster={cluster_num}. "
            f"Check your JSON/CSV and filter values."
        )

    print(
        f"      '{organelle_name}' | shape: {mask.shape} | "
        f"centroids loaded: {len(centroids)}"
    )

    # -------------------------------------------------- save binary mask
    print("[2/5] Saving binary mask...")
    np.save(f"Binary_Mask_{organelle_name}_{cell_num}.npy", (mask > 0).astype(np.uint8))

    # ----------------------------------------- connected components labelling
    print("[3/5] Running connected components labelling...")
    labels = cc3d.connected_components(mask, connectivity=18)
    print(f"      Structures found: {int(labels.max())}")

    # ----------------------------------------- centroid -> label matching
    print("[4/5] Matching centroids to labels and assigning values...")

    param_array = np.zeros_like(mask, dtype=np.float32)
    matched = 0
    unmatched = 0

    # Shared tqdm centroid loop for both modes
    for c in tqdm(centroids, desc="  Centroids", unit="centroid"):
        cx, cy, cz = c["x"], c["y"], c["z"]
        label_id = _get_label_at(cx, cy, cz, labels, window)

        if label_id == 0:
            unmatched += 1
            continue

        value = c[param_name]

        if variable_type == "continuous":
            # raw continuous value is stored first; clipping/normalization happens later
            param_array[labels == label_id] = float(value)

        else:
            # discrete/categorical mapping
            category = int(value)
            if binary:
                mapped_val = float(category)
            else:
                if num_categories is None:
                    raise ValueError(
                        "num_categories is required when variable_type='discrete' and binary=False."
                    )
                mapped_val = round(category / num_categories, 2)

            param_array[labels == label_id] = mapped_val

        matched += 1

    print(f"      Matched: {matched} / {len(centroids)}  |  Unmatched (window miss): {unmatched}")
    if unmatched > 0:
        print(f"      Tip: increase 'window' (currently {window}) if unmatched count is high.")

    # ----------------------------------------------------- mode-specific step
    print("[5/5] Finalizing and saving...")
    mask_bool = mask > 0

    if variable_type == "continuous":
        ref_values = np.array(
            [c[param_name] for c in centroids if c.get(param_name) is not None],
            dtype=np.float32,
        )

        if ref_values.size == 0:
            raise RuntimeError("No valid centroid parameter values found.")

        auto_min = float(ref_values.min())
        auto_max = float(ref_values.max())

        if min_val is None and max_val is None:
            min_val, max_val = auto_min, auto_max
            print(f"      Auto-detected range: min={min_val:.4f}  max={max_val:.4f}")
        else:
            if min_val is None:
                min_val = auto_min
            if max_val is None:
                max_val = auto_max
            print(f"      Using clip range:    min={min_val:.4f}  max={max_val:.4f}")

        if min_val >= max_val:
            raise ValueError(f"min_val ({min_val}) must be less than max_val ({max_val}).")

        # clip and normalize
        param_clipped = np.clip(param_array, min_val, max_val)
        param_clipped[~mask_bool] = 0

        if show_hist:
            bins = np.linspace(min_val, max_val, 60)
            plt.figure(figsize=(7, 3))
            plt.hist(param_clipped[mask_bool].flatten(), bins=bins, edgecolor="none")
            plt.title(f"{organelle_name} — {param_name} ({min_val:.4f} to {max_val:.4f})")
            plt.xlabel("Value")
            plt.ylabel("Structure count")
            plt.tight_layout()
            plt.show()

        param_norm = np.zeros_like(param_clipped, dtype=np.float32)
        param_norm[mask_bool] = (param_clipped[mask_bool] - min_val) / (max_val - min_val)

        out_name = f"{param_name.replace('.', '_')}_Mask_{organelle_name}_{cell_num}.npy"
        np.save(out_name, param_norm)

        if show_slice:
            z = slice_index if slice_index is not None else mask.shape[0] // 2
            plt.figure(figsize=(7, 5))
            plt.imshow(param_norm[z], cmap="plasma", vmin=0, vmax=1)
            plt.colorbar(label=f"{param_name} (normalized)")
            plt.title(f"{organelle_name} — {param_name} | z-slice {z}")
            plt.tight_layout()
            plt.show()

        print("Done! Saved:")
        print(f"  Binary_Mask_{organelle_name}_{cell_num}.npy")
        print(f"  {out_name}")
        print(
            f"  Normalized range check: "
            f"min={param_norm[mask_bool].min():.4f}  "
            f"max={param_norm[mask_bool].max():.4f}"
        )

    else:
        # discrete output
        raw_vals = [c[param_name] for c in centroids if c.get(param_name) is not None]
        if not raw_vals:
            raise RuntimeError("No valid discrete parameter values found.")

        if not all(float(v).is_integer() for v in raw_vals):
            raise ValueError(
                f"Parameter '{param_name}' contains non-integer values. "
                f"Use variable_type='continuous' for float-valued parameters."
            )

        unique_cats = sorted(set(int(v) for v in raw_vals))
        print(f"      Categories found: {unique_cats}")

        if binary:
            invalid = [v for v in unique_cats if v not in (0, 1)]
            if invalid:
                raise ValueError(
                    f"binary=True but found non-binary values: {invalid}. "
                    f"Use binary=False with num_categories for multi-category params."
                )
        else:
            if num_categories is None:
                raise ValueError(
                    "num_categories is required when variable_type='discrete' and binary=False."
                )

        if show_slice:
            z = slice_index if slice_index is not None else mask.shape[0] // 2
            plt.figure(figsize=(7, 5))
            plt.imshow(param_array[z], cmap="nipy_spectral", vmin=0, vmax=1)
            plt.colorbar(label=f"{param_name} (normalized)")
            plt.title(f"{organelle_name} — {param_name} | z-slice {z}")
            plt.tight_layout()
            plt.show()

        out_name = f"{param_name.replace('.', '_')}_Mask_{organelle_name}_{cell_num}.npy"
        np.save(out_name, param_array)

        print("Done! Saved:")
        print(f"  Binary_Mask_{organelle_name}_{cell_num}.npy")
        print(f"  {out_name}")


# ------------------------------------------------------------------ helpers

def _get_label_at(z: int, y: int, x: int, labels: np.ndarray, window: int) -> int:
    """
    Returns the most common non-zero label in a cubic window centred at (z, y, x).
    Returns 0 if no labelled voxel is found within the window.
    """
    z, y, x = int(z), int(y), int(x)
    zmin = max(0, z - window);  zmax = min(labels.shape[0], z + window + 1)
    ymin = max(0, y - window);  ymax = min(labels.shape[1], y + window + 1)
    xmin = max(0, x - window);  xmax = min(labels.shape[2], x + window + 1)

    region = labels[zmin:zmax, ymin:ymax, xmin:xmax]
    nonzero = region[region > 0]

    if nonzero.size == 0:
        return 0

    return int(np.bincount(nonzero).argmax())


def _load_stack(path: str) -> np.ndarray:
    """Loads a .mrc or .tif/.tiff image stack into a numpy array."""
    if path.endswith(".mrc"):
        import mrcfile
        with mrcfile.open(path, permissive=True) as f:
            return f.data.copy()
    elif path.endswith((".tif", ".tiff")):
        import tifffile
        return tifffile.imread(path)
    else:
        raise ValueError(f"Unsupported file format: '{path}'. Use .mrc or .tif/.tiff.")


def _load_centroids_json(
    json_file: str,
    condition: str,
    cell_num: int,
    cluster_num: int,
    param_name: str,
) -> list:
    """
    Extracts centroids from hierarchical JSON, filtered by condition and cell.
    If clustered=True and param_name == 'Cluster', the cluster id is injected
    into each centroid dict so cluster can be used as a discrete variable.
    """
    with open(json_file) as f:
        data = json.load(f)

    cell_key = f"Cell {cell_num}"

    if condition not in data["conditions"]:
        available = list(data["conditions"].keys())
        raise ValueError(f"Condition '{condition}' not found. Available: {available}")

    cond_data = data["conditions"][condition]

    if cell_key not in cond_data:
        available = list(cond_data.keys())
        raise ValueError(
            f"'{cell_key}' not found in condition '{condition}'. Available: {available}"
        )

    cell_data = cond_data[cell_key]
    clustered = data["metadata"].get("clustered", True)

    sample = _get_sample_centroid(cell_data)
    if sample and param_name not in sample and param_name != "Cluster":
        available = [k for k in sample.keys() if k not in ("x", "y", "z")]
        raise ValueError(f"Parameter '{param_name}' not found. Available: {available}")

    if param_name == "Cluster" and not clustered:
        raise ValueError("Parameter 'Cluster' requires clustered=True JSON output.")

    centroids = []

    if not clustered:
        # unclustered hierarchy: just use centroids as-is
        centroids = cell_data.get("centroids", [])
    else:
        clusters = cell_data.get("clusters", {})

        if cluster_num is not None:
            cluster_key = int(cluster_num)
            if cluster_key not in clusters:
                available = list(clusters.keys())
                raise ValueError(
                    f"Cluster {cluster_num} not found in {cell_key}. Available: {available}"
                )

            for c in clusters[cluster_key]:
                c2 = dict(c)
                c2["Cluster"] = int(cluster_key)
                centroids.append(c2)
        else:
            for cluster_key, cluster_centroids in clusters.items():
                for c in cluster_centroids:
                    c2 = dict(c)
                    c2["Cluster"] = int(cluster_key)
                    centroids.append(c2)

    centroids = [c for c in centroids if c.get(param_name) is not None]
    return centroids


def _load_centroids_csv(
    csv_file: str,
    condition: str,
    cell_num: int,
    cluster_num,
    param_name: str,
) -> list:
    """
    Loads centroids from CSV format.

    Expected columns:
        X, Y, Z, Cell, Condition, Cluster, <param_name>

    Cell values can be either:
        - "Cell 1"
        - 1
    """
    df = pd.read_csv(csv_file)

    if "Condition" not in df.columns:
        raise ValueError("CSV is missing required column: Condition")
    if "Cell" not in df.columns:
        raise ValueError("CSV is missing required column: Cell")
    if param_name not in df.columns:
        raise ValueError(f"CSV is missing required parameter column: {param_name}")

    df = df[df["Condition"].astype(str) == str(condition)]
    df["_cell_int"] = df["Cell"].apply(_parse_cell_value)
    df = df[df["_cell_int"] == int(cell_num)]

    if cluster_num is not None:
        if "Cluster" not in df.columns:
            raise ValueError("CSV is missing required column: Cluster")
        df["_cluster_int"] = df["Cluster"].apply(_parse_int_like)
        df = df[df["_cluster_int"] == int(cluster_num)]

    df = df.dropna(subset=[param_name])

    centroids = []
    for _, row in df.iterrows():
        centroids.append(
            {
                "x": float(row["X"]),
                "y": float(row["Y"]),
                "z": float(row["Z"]),
                param_name: float(row[param_name]),
            }
        )
    return centroids


def _get_sample_centroid(cell_data: dict) -> dict:
    """Returns the first centroid in a cell data block regardless of structure."""
    if "centroids" in cell_data:
        return cell_data["centroids"][0] if cell_data["centroids"] else {}
    if "clusters" in cell_data:
        for cluster_centroids in cell_data["clusters"].values():
            if cluster_centroids:
                return cluster_centroids[0]
    return {}


def _parse_cell_value(val) -> int:
    """Parses Cell values like 'Cell 1' or 1 into an integer cell index."""
    if isinstance(val, str) and val.lower().startswith("cell"):
        return int(val.strip().split()[-1])
    return int(val)


def _parse_int_like(val) -> int:
    """Parses integer-like values from ints, floats, or numeric strings."""
    if isinstance(val, str):
        return int(float(val))
    return int(val)


# ------------------------------------------------------------------ example
if __name__ == "__main__":

    # --- continuous parameter across whole cell
    voxelgen_npy_param(
        binary_file    = "vesicle_mask.mrc",
        json_file      = "centroids.json",
        organelle_name = "vesicles",
        param_name     = "LAC.Value",
        condition      = "No Stim",
        cell_num       = 1,
        variable_type  = "continuous",
        cluster_num    = None,
        min_val        = None,
        max_val        = None,
        window         = 3,
        show_hist      = True,
        show_slice     = False,
    )

    # --- discrete parameter across whole cell
    # voxelgen_npy_param(
    #     binary_file    = "vesicle_mask.mrc",
    #     json_file      = "centroids.json",
    #     organelle_name = "vesicles",
    #     param_name     = "Cluster",
    #     condition      = "No Stim",
    #     cell_num       = 1,
    #     variable_type  = "discrete",
    #     num_categories = 6,
    #     binary         = False,
    #     window         = 3,
    #     show_slice     = True,
    # )

    # --- binary discrete parameter
    # voxelgen_npy_param(
    #     binary_file    = "vesicle_mask.mrc",
    #     json_file      = "centroids.json",
    #     organelle_name = "vesicles_contact",
    #     param_name     = "Mito.Contact",
    #     condition      = "Ex4",
    #     cell_num       = 7,
    #     variable_type  = "discrete",
    #     binary         = True,
    #     window         = 3,
    #     show_slice     = True,
    # )
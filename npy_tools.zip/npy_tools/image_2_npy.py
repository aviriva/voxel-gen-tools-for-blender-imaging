"""
voxelgen_npy_imagevals.py

Generates NPY files for voxel visualization by pulling grayscale values
directly from a raw image stack, masked by a binary segmentation mask.

Inputs:
    raw_file      : path to raw image stack (.mrc or .tif)
    binary_file   : path to binary segmentation mask (.mrc or .tif)
    organelle_name: label for output filenames e.g. "vesicles", "mito"
    min_val       : (optional) hardcoded clip minimum — set to None to auto-detect
    max_val       : (optional) hardcoded clip maximum — set to None to auto-detect
    show_hist     : (optional) show histogram of clipped values before normalizing

Outputs (saved to working directory):
    Binary_Mask_{organelle_name}.npy    : binary mask array (0s and 1s)
    Param_Mask_{organelle_name}.npy     : raw masked parameter values (unclipped)
    Norm_Param_Mask_{organelle_name}.npy: normalized [0, 1] parameter values

Usage:
    Call voxelgen_npy_imagevals() directly with your file paths.
    Set min_val/max_val to None for auto-detection, or hardcode them for
    consistent cross-dataset comparisons.
"""

import numpy as np
import matplotlib.pyplot as plt


def voxelgen_npy_imagevals(
    raw_file: str,
    binary_file: str,
    organelle_name: str,
    cell_num: int,
    min_val: float = None,
    max_val: float = None,
    show_hist: bool = False,
):
    """
    Extract and normalize voxel values from a raw image stack using a binary mask.

    Parameters
    ----------
    raw_file       : path to raw grayscale image stack (.mrc or .tif)
    binary_file    : path to binary segmentation mask (.mrc or .tif)
    organelle_name : label used in output filenames
    min_val        : clip minimum — None = auto-detect from masked values
    max_val        : clip maximum — None = auto-detect from masked values
    show_hist      : if True, shows histogram of clipped values before normalizing
    """

    # ------------------------------------------------------------------ load
    print(f"[1/4] Loading files...")
    raw, mask = _load_stack(raw_file), _load_stack(binary_file)

    if raw.shape != mask.shape:
        raise ValueError(
            f"Shape mismatch: raw {raw.shape} vs mask {mask.shape}. "
            "Arrays must have identical dimensions."
        )

    print(f"      '{organelle_name}' | shape: {mask.shape} | "
          f"masked voxels: {np.count_nonzero(mask):,}")

    # -------------------------------------------------- save binary mask
    print(f"[2/4] Applying mask and saving binary + param arrays...")
    np.save(f"Binary_Mask_{organelle_name}_{cell_num}.npy", (mask > 0).astype(np.uint8))

    # -------------------------------------------- apply mask to raw image
    param = np.where(mask > 0, raw, 0).astype(np.float32)
    # np.save(f"Param_Mask_{organelle_name}.npy", param)

    # ------------------------------------------- determine clip min / max
    print(f"[3/4] Clipping outliers...")
    param_nonzero = param[mask > 0]

    auto_min = float(param_nonzero.min())
    auto_max = float(param_nonzero.max())

    if min_val is None and max_val is None:
        min_val, max_val = auto_min, auto_max
        print(f"      Auto-detected range: min={min_val:.4f}  max={max_val:.4f}")
    else:
        if min_val is None:
            min_val = auto_min
        if max_val is None:
            max_val = auto_max
        print(f"      Using clip range:    min={min_val:.4f}  max={max_val:.4f}")

    if min_val >= max_val:
        raise ValueError(f"min_val ({min_val}) must be less than max_val ({max_val}).")

    # ------------------------------------------------------- clip outliers
    # Both clips operate on param_clipped (bug fix: was using `param` in second clip)
    param_clipped = np.where(param < min_val, min_val, param)
    param_clipped = np.where(param_clipped > max_val, max_val, param_clipped)

    # Zero out non-masked voxels that got pulled up to min_val by the clip
    param_clipped[mask == 0] = 0

    if show_hist:
        bins = np.linspace(min_val, max_val, 60)
        plt.figure(figsize=(7, 3))
        plt.hist(param_clipped[mask > 0].flatten(), bins=bins, color="steelblue", edgecolor="none")
        plt.title(f"{organelle_name} — clipped values ({min_val:.4f} to {max_val:.4f})")
        plt.xlabel("Value")
        plt.ylabel("Voxel count")
        plt.tight_layout()
        plt.show()

    # ----------------------------------------------------------- normalize
    print(f"[4/4] Normalizing and saving...")
    param_norm = np.zeros_like(param_clipped, dtype=np.float32)
    mask_bool = mask > 0
    param_norm[mask_bool] = (param_clipped[mask_bool] - min_val) / (max_val - min_val)

    np.save(f"Image_Mask_{organelle_name}_{cell_num}.npy", param_norm)

    print(f"Done! Saved:")
    print(f"  Binary_Mask_{organelle_name}_{cell_num}.npy")
    print(f"  Image_Mask_{organelle_name}_{cell_num}.npy")
    print(f"  Normalized range check: "
          f"min={param_norm[mask_bool].min():.4f}  "
          f"max={param_norm[mask_bool].max():.4f}")


# ------------------------------------------------------------------ helpers

def _load_stack(path: str) -> np.ndarray:
    """Loads a .mrc or .tif image stack into a numpy array."""
    if path.endswith(".mrc"):
        import mrcfile
        with mrcfile.open(path, permissive=True) as f:
            return f.data.copy()
    elif path.endswith((".tif", ".tiff")):
        import tifffile
        data = tifffile.imread(path)
        return np.flip(data, axis=1)
    else:
        raise ValueError(f"Unsupported file format: '{path}'. Use .mrc or .tif/.tiff.")


# ------------------------------------------------------------------ example
if __name__ == "__main__":

    # --- auto-detected min/max (most common for exploratory use)
    voxelgen_npy_imagevals(
        raw_file       = "raw_image.mrc",
        binary_file    = "vesicle_mask.mrc",
        organelle_name = "vesicles",
        min_val        = None,       # auto-detect
        max_val        = None,       # auto-detect
        show_hist      = True,
    )

    # --- hardcoded min/max (use for cross-dataset comparisons)
    # voxelgen_npy_imagevals(
    #     raw_file       = "raw_image.mrc",
    #     binary_file    = "mito_mask.tif",
    #     organelle_name = "mito",
    #     min_val        = 0.25,
    #     max_val        = 0.38,
    #     show_hist      = True,
    # )
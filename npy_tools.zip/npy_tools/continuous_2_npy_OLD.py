"""
voxelgen_npy_rangeparam.py

Generates NPY files for voxel visualization by mapping a continuous
parameter (e.g. LAC, volume, diameter) from a centroid JSON onto whole
organelle structures using connected components labelling.

Each organelle in the binary mask is assigned the parameter value of its
nearest centroid from the JSON. Values are normalized to [0, 1].

Inputs:
    binary_file    : path to binary segmentation mask (.mrc or .tif)
    json_file      : path to centroid JSON (produced by csv_to_json.py)
    organelle_name : label for output filenames e.g. "vesicles"
    param_name     : which parameter column to map e.g. "LAC.Value"
    condition      : condition to filter by e.g. "No Stim" or "Ex4"
    cell_num       : integer cell number e.g. 1 for "Cell 1"
    cluster_num    : (optional) integer cluster to filter by — None = whole cell
    min_val        : clip minimum — None = auto-detect from centroid values
    max_val        : clip maximum — None = auto-detect from centroid values
    window         : voxel search radius around each centroid (default 3)
    show_hist      : if True, shows histogram of assigned values before normalizing

Outputs (saved to working directory):
    Binary_Mask_{organelle_name}_{cell_num}.npy
    Norm_{param_name}_Mask_{organelle_name}_{cell_num}.npy

Usage:
    Call voxelgen_npy_rangeparam() with your file paths and filter options.
"""

import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cc3d
from tqdm import tqdm


def voxelgen_npy_rangeparam(
    binary_file: str,
    organelle_name: str,
    param_name: str,
    condition: str,
    cell_num: int,
    json_file: str = None,
    csv_file: str = None,
    cluster_num: int = None,
    min_val: float = None,
    max_val: float = None,
    window: int = 3,
    show_hist: bool = False,
):
    """
    Map a continuous parameter from centroid JSON/CSV onto organelle structures.

    Assignment direction: each centroid locates its own label in the
    cc3d array via a voxel window search, then floods that label with the
    parameter value.

    Normalization uses the full filtered centroid population, matching the
    old assignment behavior.
    """

    # ------------------------------------------------------------------ load
    print(f"[1/5] Loading files...")
    mask = _load_stack(binary_file)

    if csv_file is not None:
        centroids = _load_centroids_csv(csv_file, condition, cell_num, cluster_num, param_name)
    elif json_file is not None:
        centroids = _load_centroids(json_file, condition, cell_num, cluster_num, param_name)
    else:
        raise ValueError("Provide either csv_file or json_file.")

    if not centroids:
        raise ValueError(
            f"No centroids found for condition='{condition}', "
            f"cell={cell_num}, cluster={cluster_num}. "
            f"Check your JSON and filter values."
        )

    print(f"      '{organelle_name}' | shape: {mask.shape} | centroids loaded: {len(centroids)}")

    # -------------------------------------------------- save binary mask
    print(f"[2/5] Saving binary mask...")
    np.save(f"Binary_Mask_{organelle_name}_{cell_num}.npy", (mask > 0).astype(np.uint8))

    # ----------------------------------------- connected components labelling
    print(f"[3/5] Running connected components labelling...")
    labels = cc3d.connected_components(mask, connectivity=18)
    print(f"      Structures found: {int(labels.max())}")

    # ----------------------------------------- centroid -> label matching
    print(f"[4/5] Matching centroids to labels and assigning parameters...")

    param_array = np.zeros_like(mask, dtype=np.float32)
    matched = 0
    unmatched = 0

    # Use all filtered centroid values for normalization reference
    ref_values = np.array(
        [c[param_name] for c in centroids if c.get(param_name) is not None],
        dtype=np.float32,
    )

    for c in tqdm(centroids, desc="  Centroids", unit="centroid"):
        # Keep old behavior: use the centroid coordinates directly, then cast in helper
        cx, cy, cz = c["x"], c["y"], c["z"]

        label_id = _get_label_at(cx, cy, cz, labels, window)

        if label_id == 0:
            unmatched += 1
            continue

        param_array[labels == label_id] = float(c[param_name])
        matched += 1

    print(f"      Matched: {matched} / {len(centroids)}  |  Unmatched (window miss): {unmatched}")
    if unmatched > 0:
        print(f"      Tip: increase 'window' (currently {window}) if unmatched count is high.")

    # ----------------------------------------- determine clip min / max
    print(f"[5/5] Clipping, normalizing and saving...")
    mask_bool = mask > 0

    if ref_values.size == 0:
        raise RuntimeError("No valid centroid parameter values found.")

    auto_min = float(ref_values.min())
    auto_max = float(ref_values.max())

    if min_val is None and max_val is None:
        min_val, max_val = auto_min, auto_max
        print(f"      Auto-detected range: min={min_val:.4f}  max={max_val:.4f}")
    else:
        if min_val is None:
            min_val = auto_min
        if max_val is None:
            max_val = auto_max
        print(f"      Using clip range:    min={min_val:.4f}  max={max_val:.4f}")

    if min_val >= max_val:
        raise ValueError(f"min_val ({min_val}) must be less than max_val ({max_val}).")

    # ------------------------------------------------------- clip outliers
    param_clipped = np.clip(param_array, min_val, max_val)
    param_clipped[~mask_bool] = 0

    if show_hist:
        bins = np.linspace(min_val, max_val, 60)
        plt.figure(figsize=(7, 3))
        plt.hist(param_clipped[mask_bool].flatten(), bins=bins, edgecolor="none")
        plt.title(f"{organelle_name} — {param_name} ({min_val:.4f} to {max_val:.4f})")
        plt.xlabel("Value")
        plt.ylabel("Structure count")
        plt.tight_layout()
        plt.show()

    # ----------------------------------------------------------- normalize
    param_norm = np.zeros_like(param_clipped, dtype=np.float32)
    param_norm[mask_bool] = (param_clipped[mask_bool] - min_val) / (max_val - min_val)

    out_name = f"{param_name.replace('.', '_')}_Mask_{organelle_name}_{cell_num}.npy"
    np.save(out_name, param_norm)

    print(f"Done! Saved:")
    print(f"  Binary_Mask_{organelle_name}_{cell_num}.npy")
    print(f"  {out_name}")
    print(
        f"  Normalized range check: "
        f"min={param_norm[mask_bool].min():.4f}  "
        f"max={param_norm[mask_bool].max():.4f}"
    )


# ------------------------------------------------------------------ helpers

def _get_label_at(z: int, y: int, x: int, labels: np.ndarray, window: int) -> int:
    """
    Returns the most common non-zero label in a cubic window centered at (z, y, x).
    Returns 0 if no labelled voxel is found within the window.
    """
    z, y, x = int(z), int(y), int(x)
    zmin = max(0, z - window);  zmax = min(labels.shape[0], z + window + 1)
    ymin = max(0, y - window);  ymax = min(labels.shape[1], y + window + 1)
    xmin = max(0, x - window);  xmax = min(labels.shape[2], x + window + 1)

    region = labels[zmin:zmax, ymin:ymax, xmin:xmax]
    nonzero = region[region > 0]

    if nonzero.size == 0:
        return 0

    return int(np.bincount(nonzero).argmax())


def _load_stack(path: str) -> np.ndarray:
    """Loads a .mrc or .tif/.tiff image stack into a numpy array."""
    if path.endswith(".mrc"):
        import mrcfile
        with mrcfile.open(path, permissive=True) as f:
            return f.data.copy()
    elif path.endswith((".tif", ".tiff")):
        import tifffile
        return tifffile.imread(path)
    else:
        raise ValueError(f"Unsupported file format: '{path}'. Use .mrc or .tif/.tiff.")


def _load_centroids(
    json_file: str,
    condition: str,
    cell_num: int,
    cluster_num: int,
    param_name: str,
) -> list:
    """
    Extracts centroid list from the hierarchical JSON, filtered by
    condition, cell, and optionally cluster.
    """
    with open(json_file) as f:
        data = json.load(f)

    cell_key = f"Cell {cell_num}"

    if condition not in data["conditions"]:
        available = list(data["conditions"].keys())
        raise ValueError(f"Condition '{condition}' not found. Available: {available}")

    cond_data = data["conditions"][condition]

    if cell_key not in cond_data:
        available = list(cond_data.keys())
        raise ValueError(f"'{cell_key}' not found in condition '{condition}'. Available: {available}")

    cell_data = cond_data[cell_key]

    sample = _get_sample_centroid(cell_data)
    if sample and param_name not in sample:
        available = [k for k in sample.keys() if k not in ("x", "y", "z")]
        raise ValueError(f"Parameter '{param_name}' not found. Available: {available}")

    clustered = data["metadata"].get("clustered", True)

    if not clustered:
        centroids = cell_data["centroids"]
    elif cluster_num is not None:
        cluster_key = int(cluster_num)
        clusters = cell_data.get("clusters", {})
        if cluster_key not in clusters:
            available = list(clusters.keys())
            raise ValueError(
                f"Cluster {cluster_num} not found in {cell_key}. Available: {available}"
            )
        centroids = clusters[cluster_key]
    else:
        centroids = []
        for cluster_centroids in cell_data.get("clusters", {}).values():
            centroids.extend(cluster_centroids)

    centroids = [c for c in centroids if c.get(param_name) is not None]
    return centroids


def _get_sample_centroid(cell_data: dict) -> dict:
    """Returns the first centroid in a cell data block regardless of structure."""
    if "centroids" in cell_data:
        return cell_data["centroids"][0] if cell_data["centroids"] else {}
    if "clusters" in cell_data:
        for cluster_centroids in cell_data["clusters"].values():
            if cluster_centroids:
                return cluster_centroids[0]
    return {}


def _load_centroids_csv(
    csv_file: str,
    condition: str,
    cell_num: int,
    cluster_num,
    param_name: str,
) -> list:
    """
    Loads centroids from the original CSV format.

    Expected columns: X, Y, Z, Cell, Condition, Cluster, <param_name>
    """
    cell_key = f"Cell {cell_num}"
    df = pd.read_csv(csv_file)
    df = df[df["Condition"] == condition]
    df = df[df["Cell"] == cell_key]

    if cluster_num is not None:
        df = df[df["Cluster"] == cluster_num]

    df = df.dropna(subset=[param_name])

    centroids = []
    for _, row in df.iterrows():
        centroids.append({
            "x": float(row["X"]),
            "y": float(row["Y"]),
            "z": float(row["Z"]),
            param_name: float(row[param_name]),
        })
    return centroids


# ------------------------------------------------------------------ example
if __name__ == "__main__":

    # --- whole cell, auto-detected range
    # --- using CSV (original format)
    voxelgen_npy_rangeparam(
        binary_file    = "vesicle_mask.mrc",
        csv_file       = "centroids.csv",
        organelle_name = "vesicles",
        param_name     = "LAC.Value",
        condition      = "GIP",
        cell_num       = 13,
        cluster_num    = None,
        min_val        = None,
        max_val        = None,
        window         = 3,
        show_hist      = True,
    )

    # --- using JSON (from csv_to_json.py)
    # voxelgen_npy_rangeparam(
    #     binary_file    = "vesicle_mask.mrc",
    #     json_file      = "centroids.json",
    #     organelle_name = "vesicles",
    #     param_name     = "LAC.Value",
    #     condition      = "GIP",
    #     cell_num       = 13,
    #     cluster_num    = None,
    #     min_val        = None,
    #     max_val        = None,
    #     window         = 3,
    #     show_hist      = True,
    # )

    # --- filtered to cluster 2, hardcoded range
    # voxelgen_npy_rangeparam(
    #     binary_file    = "vesicle_mask.mrc",
    #     json_file      = "centroids.json",
    #     organelle_name = "vesicles_cluster2",
    #     param_name     = "LAC.Value",
    #     condition      = "Ex4",
    #     cell_num       = 7,
    #     cluster_num    = 2,
    #     min_val        = 0.25,
    #     max_val        = 0.38,
    #     window         = 3,
    #     show_hist      = True,
    # )